{\rtf1\ansi\ansicpg1252\cocoartf949\cocoasubrtf540
{\fonttbl\f0\fswiss\fcharset0 Helvetica;\f1\froman\fcharset0 Times-Roman;}
{\colortbl;\red255\green255\blue255;}
{\info
{\author M.Franck}
{\*\company BullzArtDesign}
{\*\copyright Copyright - Bullzartdesign - 2009}}\paperw11900\paperh16840\margl1440\margr1440\vieww12780\viewh19100\viewkind1
\pard\tx560\tx1120\tx1680\tx2240\tx2800\tx3360\tx3920\tx4480\tx5040\tx5600\tx6160\tx6720\ql\qnatural\pardirnatural

\f0\b\fs28 \cf0 US/EN
\b0\fs24 \
\

\fs28 Thank you for uploading this "Doodle Sketchy Social" Buttons Pack  !!!\
\
This Icons pack is made available free for personal use, you can not under any circumstances use them for commercial or mercantile.\
\

\b Files subject to conditions under Creative Commons license.
\b0\fs24 \
\
\pard\pardeftab720\ql\qnatural

\f1 \cf0 \
\pard\pardeftab720\ql\qnatural

\b\fs28 \cf0 Attribution
\b0\fs24 \

\b\fs28 BY
\b0\fs24 \
\pard\pardeftab720\sa240\ql\qnatural

\fs28 \cf0 You let others copy, distribute, display, and perform your copyrighted work \'97 and derivative works based upon it \'97 but only if they give credit the way you request.
\fs24 \
\pard\pardeftab720\ql\qnatural
\cf0 \
\pard\pardeftab720\ql\qnatural

\b\fs28 \cf0 Share Alike
\b0\fs24 \

\b\fs28 SA
\b0\fs24 \
\pard\pardeftab720\sa240\ql\qnatural

\fs28 \cf0 You allow others to distribute derivative works only under a license identical to the license that governs your work.
\fs24 \
\pard\pardeftab720\ql\qnatural
\cf0 \
\pard\pardeftab720\ql\qnatural

\b\fs28 \cf0 Non-Commercial
\b0\fs24 \

\b\fs28 ND
\b0\fs24 \
\pard\pardeftab720\sa240\ql\qnatural

\fs28 \cf0 You let others copy, distribute, display, and perform your work \'97 and derivative works based upon it \'97 but for non-commercial purposes only.
\fs24 \
\pard\pardeftab720\ql\qnatural
\cf0 \
\pard\pardeftab720\ql\qnatural

\b\fs28 \cf0 No Derivative Works
\b0 \

\b ND
\b0\fs24 \
\pard\pardeftab720\sa240\ql\qnatural

\fs28 \cf0 You let others copy, distribute, display, and perform only verbatim copies of your work, not derivative works based upon it.
\fs24 \
\pard\tx560\tx1120\tx1680\tx2240\tx2800\tx3360\tx3920\tx4480\tx5040\tx5600\tx6160\tx6720\ql\qnatural\pardirnatural

\f0 \cf0 \
\
\pard\tx560\tx1120\tx1680\tx2240\tx2800\tx3360\tx3920\tx4480\tx5040\tx5600\tx6160\tx6720\ql\qnatural\pardirnatural

\b\fs28 \cf0 \ul \ulc0 For additional information, please contact:
\b0 \ulnone \
\
mail: 
\i\b BullzArtDesign@gmail.com
\i0\b0 \
\
via twitter: 
\i\b @bullzartdesign
\i0\b0\fs24 \
\pard\tx560\tx1120\tx1680\tx2240\tx2800\tx3360\tx3920\tx4480\tx5040\tx5600\tx6160\tx6720\ql\qnatural\pardirnatural
\cf0 \
\
\pard\tx560\tx1120\tx1680\tx2240\tx2800\tx3360\tx3920\tx4480\tx5040\tx5600\tx6160\tx6720\ql\qnatural\pardirnatural

\b \cf0 FR/CA
\b0 \
\
\pard\tx560\tx1120\tx1680\tx2240\tx2800\tx3360\tx3920\tx4480\tx5040\tx5600\tx6160\tx6720\ql\qnatural\pardirnatural

\fs28 \cf0 Merci d'avoir t\'e9l\'e9charg\'e9 notre pack d'ic\'f4nes "Doodle Sketchy Social" !!!\
\
Ce Pack d'ic\'f4nes est mis \'e0 votre disposition gratuitement pour un usage strictement personnel, vous ne pouvez en aucun cas les utiliser \'e0 des fins commerciales ou mercantiles.\
\

\b Fichiers soumis \'e0 conditions sous licence Creative Commons
\b0 . 
\fs24 \
\
\
\pard\pardeftab720\ql\qnatural

\f1\b\fs28 \cf0 Attribution
\b0\fs24 \

\b\fs28 BY
\b0\fs24 \
\pard\pardeftab720\ql\qnatural

\fs28 \cf0 Qu'on laisse les autres de copier, distribuer, afficher et ex\'e9cuter votre travail d'auteur - et des oeuvres d\'e9riv\'e9es bas\'e9es sur elle - mais seulement si ils font cr\'e9dit comme vous le demande.
\fs24 \
\
\pard\pardeftab720\ql\qnatural

\b\fs28 \cf0 Share Alike
\b0\fs24 \

\b\fs28 SA
\b0\fs24 \
\pard\pardeftab720\ql\qnatural

\fs28 \cf0 Vous autorisez les autres \'e0 distribuer les \'9cuvres d\'e9riv\'e9es uniquement sous un contrat identique \'e0 la licence qui r\'e9git votre travail.
\fs24 \
\
\pard\pardeftab720\ql\qnatural

\b\fs28 \cf0 Non-Commercial
\b0\fs24 \

\b\fs28 NC
\b0\fs24 \
\pard\pardeftab720\ql\qnatural

\fs28 \cf0 Qu'on laisse les autres de copier, distribuer, afficher et ex\'e9cuter votre travail - et des oeuvres d\'e9riv\'e9es bas\'e9es sur elle - mais \'e0 des fins non commerciales seulement.
\fs24 \
\
\pard\pardeftab720\ql\qnatural

\b\fs28 \cf0 Pas de Modification
\b0\fs24 \

\b\fs28 ND
\b0\fs24 \
\pard\pardeftab720\ql\qnatural

\fs28 \cf0 Qu'on laisse les autres de copier, distribuer, afficher, et d'effectuer seulement des copies exactes de votre travail, pas d'oeuvres d\'e9riv\'e9es bas\'e9es sur elle.
\f0\fs24 \
\pard\tx560\tx1120\tx1680\tx2240\tx2800\tx3360\tx3920\tx4480\tx5040\tx5600\tx6160\tx6720\ql\qnatural\pardirnatural
\cf0 \
\
\
\pard\tx560\tx1120\tx1680\tx2240\tx2800\tx3360\tx3920\tx4480\tx5040\tx5600\tx6160\tx6720\ql\qnatural\pardirnatural

\b\fs28 \cf0 \ul \ulc0 Pour toutes informations suppl\'e9mentaires, veuillez contacter :
\b0 \ulnone \
\
par mail : 
\i\b BullzArtDesign@gmail.com
\i0\b0 \
\
via twitter : 
\i\b @bullzartdesign}5013